class QuestionBank {
  String image;
  String option_a;
  String option_b;
  String option_c;
  String option_d;
  String answer;

  QuestionBank(this.image, this.option_a, this.option_b, this.option_c,
      this.option_d, this.answer);
}